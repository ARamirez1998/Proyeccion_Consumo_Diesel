# Proyeccion_Consumo_Diesel
En el contexto del transporte público de Quito, una gestión eficiente del abastecimiento de diésel es crucial para asegurar la operación continua de las unidades. Sin embargo, la planificación del consumo muchas veces se realiza sin considerar patrones históricos o predicciones.
